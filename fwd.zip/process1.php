<?php
	$name = $_POST['name'];
	$username = $_POST['uname'];
	$place = $_POST['place'];
	$contact = $_POST['contact'];
    $password = $_POST['psw'];

    $name = stripcslashes($name);
	$username = stripcslashes($username);
	$place = stripcslashes($place);
	$contact = stripcslashes($contact);
	$password = stripcslashes($password);
	

	$db = mysqli_connect("localhost","root", "","user");

	$result = mysqli_query($db,"select * from table1 where  name ='$name' and  username = '$username' and contact ='$contact' and password = '$password'")
				or die("Failed to query databse".mysqli_error());
	$row = mysqli_fetch_array($result);
	if ($row['username'] == $username && $row['password'] == $password ){
		echo "Registration successfull success!!! Welcome".$row['username'];
	}else{
		echo "Failed to register;";
	}
?>